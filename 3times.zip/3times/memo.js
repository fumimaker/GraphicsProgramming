
    noStroke();
    fill(255, 128, 0,a);
    rect(a, a, width/2, height/2);
    a++;
